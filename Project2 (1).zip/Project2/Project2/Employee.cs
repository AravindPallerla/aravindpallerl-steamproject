﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class Employee
    {
        public int employeeId,  departmentId;
        public string employeeName, email, phone;

        public Employee(int employeeId, string phone, int departmentId, string employeeName, string email)
        {
            this.employeeId = employeeId;
            this.phone = phone;
            this.departmentId = departmentId;
            this.employeeName = employeeName;
            this.email = email;
        }

        public void Display()
        {
            Console.WriteLine(employeeId.ToString().PadLeft(10) + " | " + employeeName.PadLeft(10) + "|" + email.PadLeft(10) + "|" + phone.ToString().PadLeft(10));
        }

        public string OutputString()
        {
            return employeeId.ToString().PadLeft(10) + "," + employeeName.PadLeft(10) + "," + email.PadLeft(10) + "," + phone.PadLeft(10) + "," + departmentId.ToString().PadLeft(10);
        }
    }
}
