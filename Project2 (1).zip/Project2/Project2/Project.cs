﻿namespace Project2
{
    class Project
    {
        public int projectId, departmentId, employeeId;
        public string projectName;

        public Project(int projectId, int departmentId, int employeeId, string projectName)
        {
            this.projectId = projectId;
            this.departmentId = departmentId;
            this.employeeId = employeeId;
            this.projectName = projectName;
        }

        public string OutputStream()
        {
            return projectId.ToString().PadLeft(10) + "," + projectName.PadLeft(10) + "," + departmentId.ToString().PadLeft(10) + "," + employeeId.ToString().PadLeft(10);
        }
    }
}
