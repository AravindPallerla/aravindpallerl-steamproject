﻿namespace Project2
{
    class Department
    {
        public string departmentName;
        public int departmentId, numberOfProjects;

        public Department(string departmentName, int departmentId, int numberOfProjects)
        {
            this.departmentName = departmentName;
            this.departmentId = departmentId;
            this.numberOfProjects = numberOfProjects;
        }

        public string OutputStream()
        {
            return departmentId.ToString().PadLeft(10) + "," + departmentName.PadLeft(10) + "," + numberOfProjects.ToString().PadLeft(10);
        }
    }
}
